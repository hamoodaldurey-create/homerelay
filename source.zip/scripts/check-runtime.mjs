import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFileSync, realpathSync, readdirSync} from 'node:fs';
import {resolve} from 'node:path';
const require = createRequire(realpathSync(resolve('node_modules/wrangler/package.json')));
const {Miniflare} = require('miniflare');
const config = JSON.parse(readFileSync('dist/server/wrangler.json', 'utf8'));
const main = resolve('dist/server', config.main);
const modules = [main, ...readdirSync('dist/server', {recursive: true})
  .filter(path => /\.(?:js|mjs)$/.test(path)).map(path => resolve('dist/server', path)).filter(path => path !== main)];
const runtime = new Miniflare({
  modules: modules.map(path => ({type: 'ESModule', path})),
  compatibilityDate: config.compatibility_date,
  compatibilityFlags: config.compatibility_flags,
  d1Databases: ['DB'],
});
const origin = 'http://homerelay.test';
let cookie = '';
const headers = {'Content-Type': 'application/json', Accept: 'application/json, text/event-stream', 'MCP-Protocol-Version': '2025-11-25'};
async function tool(name, args) {
  const response = await runtime.dispatchFetch(origin + '/mcp', {method: 'POST', headers, body: JSON.stringify({jsonrpc: '2.0', id: name, method: 'tools/call', params: {name, arguments: args}})});
  assert.equal(response.status, 200);
  const result = await response.json(); assert.equal(result.result.isError, false);
  return result.result.structuredContent;
}
async function household() {
  const response = await runtime.dispatchFetch(origin + '/api/household', {headers: cookie ? {Cookie: cookie} : {}});
  const result = await response.json(); assert.equal(response.status, 200, JSON.stringify(result));
  if (!cookie) cookie = response.headers.get('set-cookie').split(';')[0];
  return result;
}
async function action(operation, revision) {
  const response = await runtime.dispatchFetch(origin + '/api/household', {method: 'POST', headers: {'Content-Type': 'application/json', Origin: origin, Cookie: cookie}, body: JSON.stringify({...operation, revision})});
  return {status: response.status, body: await response.json()};
}
try {
  await runtime.ready;
  const database = await runtime.getD1Database('DB');
  await database.prepare(readFileSync('drizzle/0000_woozy_tusk.sql', 'utf8')).run();
  const page = await runtime.dispatchFetch(origin + '/');
  assert.equal(page.status, 200); assert.match(await page.text(), /Keep the morning moving/);
  const initialized = await runtime.dispatchFetch(origin + '/mcp', {method: 'POST', headers, body: JSON.stringify({jsonrpc: '2.0', id: 1, method: 'initialize', params: {protocolVersion: '2025-11-25', capabilities: {}, clientInfo: {name: 'HomeRelay runtime check', version: '1.0'}}})});
  assert.equal(initialized.status, 200); assert.equal((await initialized.json()).result.protocolVersion, '2025-11-25');
  const ready = await runtime.dispatchFetch(origin + '/mcp', {method: 'POST', headers, body: JSON.stringify({jsonrpc: '2.0', method: 'notifications/initialized'})});
  assert.equal(ready.status, 202);
  const listed = await runtime.dispatchFetch(origin + '/mcp', {method: 'POST', headers, body: JSON.stringify({jsonrpc: '2.0', id: 2, method: 'tools/list'})});
  const tools = (await listed.json()).result.tools; assert.equal(tools.length, 3); assert.ok(tools[1].inputSchema.properties.household.properties.members.items.properties.from);
  const original = await household();
  const plan = await tool('replan_household', {household: original.state, disruption: {memberId: 'lena', delay: 30, unavailable: false}});
  assert.equal(plan.assignments.length, 4); assert.equal(plan.changes, 2);
  const approved = await action({action: 'approve', plan}, original.revision);
  assert.equal(approved.status, 200, JSON.stringify(approved.body));
  const reloaded = await household();
  assert.deepEqual(reloaded.state.approvedPlan.assignments, plan.assignments);
  assert.equal(reloaded.state.members.find(member => member.id === 'lena').from, 480);
  const stale = await action({action: 'approve', plan}, original.revision); assert.equal(stale.status, 409);
  const partial = await tool('replan_household', {household: reloaded.state, disruption: {memberId: 'omar', delay: 0, unavailable: true}});
  assert.ok(partial.unassigned.some(task => task.taskId === 'school'));
  const partiallyApproved = await action({action: 'approve', plan: partial}, reloaded.revision); assert.equal(partiallyApproved.status, 200, JSON.stringify(partiallyApproved.body));
  const impossibleCompletion = await action({action: 'acknowledge', taskId: 'school'}, partiallyApproved.body.revision); assert.equal(impossibleCompletion.status, 400);
  const completed = await action({action: 'acknowledge', taskId: 'cat'}, partiallyApproved.body.revision); assert.equal(completed.status, 200);
  assert.equal(completed.body.state.tasks.find(task => task.id === 'cat').done, true);
  const separate = await runtime.dispatchFetch(origin + '/api/household');
  assert.equal((await separate.json()).state.approvedPlan, null);
  const foreign = await runtime.dispatchFetch(origin + '/api/household', {method: 'POST', headers: {'Content-Type': 'application/json', Origin: 'https://other.example', Cookie: cookie}, body: JSON.stringify({action: 'reset', revision: completed.body.revision})});
  assert.equal(foreign.status, 403);
  console.log('Built Worker runtime passed: rendered page; MCP initialize/discovery/planning; D1 approval and reload; stale-write rejection; partial planning; unresolved completion rejection; valid acknowledgment; separate demo workspace; origin checks.');
} finally {await runtime.dispose();}
