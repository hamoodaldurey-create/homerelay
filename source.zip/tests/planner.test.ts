import {test} from 'node:test';
import assert from 'node:assert/strict';
import {initialState,planHousehold,scenarioFromText,handoffDraft,approvePlan,acknowledgeTask,stateSchema} from '../lib/planner';
import {dispatch,PROTOCOL} from '../lib/mcp';
test('late parent produces feasible handoffs with no overlap',()=>{const s=initialState(),p=planHousehold(s,{memberId:'lena',delay:30});assert.equal(p.unassigned.length,0);assert.equal(p.assignments.find(a=>a.taskId==='school')?.owner,'omar');assert.equal(p.assignments.find(a=>a.taskId==='lunch')?.owner,'ivy');for(const a of p.assignments){const t=s.tasks.find(t=>t.id===a.taskId)!,m=s.members.find(m=>m.id===a.owner)!;assert.ok(a.end<=t.deadline);assert.ok(m.skills.includes(t.skill));assert.equal(a.end-a.start,t.duration);for(const b of p.assignments.filter(b=>b.owner===a.owner&&b.taskId!==a.taskId))assert.ok(a.end<=b.start||b.end<=a.start);}});
test('capacity shortage stays unresolved rather than becoming a fake schedule',()=>{const s=initialState();s.members=s.members.map(m=>({...m,skills:['home']}));const p=planHousehold(s,{memberId:'lena',delay:0});assert.ok(p.unassigned.some(t=>t.taskId==='school'));assert.ok(!p.assignments.some(t=>t.taskId==='school'));});
test('finished tasks are excluded and input is not mutated',()=>{const s=initialState();s.tasks[0].done=true;const before=JSON.stringify(s),p=planHousehold(s,{memberId:'lena',delay:0});assert.ok(!p.assignments.some(a=>a.taskId==='school'));assert.equal(JSON.stringify(s),before);});
test('invalid delay and unknown members are rejected',()=>{assert.throws(()=>planHousehold(initialState(),{memberId:'lena',delay:-1}));assert.throws(()=>planHousehold(initialState(),{memberId:'unknown',delay:1}));});
test('scenario parsing respects explicit numbers and does not pretend to be general AI',()=>{assert.equal(scenarioFromText('Omar is 45 minutes late',initialState()).delay,45);assert.equal(scenarioFromText('Omar is 45 minutes late',initialState()).memberId,'omar');assert.throws(()=>scenarioFromText('hello',initialState()));});
test('handoffs are drafts and carry real assigned times',()=>{const s=initialState(),p=planHousehold(s,{memberId:'lena',delay:30}),d=handoffDraft(s,p);assert.equal(d.length,p.changes);assert.ok(d.every(x=>x.status==='draft'));});
test('MCP initialization and discovery agree on protocol and actual tools',()=>{const i=dispatch({jsonrpc:'2.0',id:1,method:'initialize',params:{protocolVersion:PROTOCOL}}) as any;assert.equal(i.result.protocolVersion,PROTOCOL);const t=dispatch({jsonrpc:'2.0',id:2,method:'tools/list'}) as any;assert.equal(t.result.tools.length,3);assert.ok(t.result.tools.every((x:any)=>x.annotations.readOnlyHint));});
test('MCP tool failures have isError, unknown methods have protocol errors',()=>{const invalid=dispatch({jsonrpc:'2.0',id:1,method:'tools/call',params:{name:'replan_household',arguments:{}}}) as any;assert.equal(invalid.result.isError,true);const unknown=dispatch({jsonrpc:'2.0',id:2,method:'bad'}) as any;assert.equal(unknown.error.code,-32601);assert.equal(dispatch({jsonrpc:'2.0',method:'notifications/initialized'}),null);});

import {POST,GET} from '../app/mcp/route';
const request=(body:unknown,extra:Record<string,string>={})=>new Request('https://homerelay.example/mcp',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json, text/event-stream','MCP-Protocol-Version':PROTOCOL,...extra},body:JSON.stringify(body)});
test('HTTP transport initializes, acknowledges, and calls a real tool',async()=>{const init=await POST(request({jsonrpc:'2.0',id:1,method:'initialize',params:{protocolVersion:PROTOCOL}}));assert.equal(init.status,200);const ready=await POST(request({jsonrpc:'2.0',method:'notifications/initialized'}));assert.equal(ready.status,202);const called=await POST(request({jsonrpc:'2.0',id:2,method:'tools/call',params:{name:'get_demo_household',arguments:{}}}));const result=await called.json() as any;assert.equal(result.result.structuredContent.tasks.length,4);assert.equal(GET().status,405);});
test('HTTP transport rejects foreign origins and unsupported protocol versions',async()=>{const body={jsonrpc:'2.0',id:1,method:'ping'};assert.equal((await POST(request(body,{Origin:'https://unrelated.example'}))).status,403);assert.equal(GET(new Request('https://homerelay.example/mcp',{headers:{Origin:'https://unrelated.example'}})).status,403);assert.equal((await POST(request(body,{'MCP-Protocol-Version':'1900-01-01'}))).status,400);assert.equal((await POST(request(body,{Accept:'application/json'}))).status,406);});

test('owner alternatives keep scarce driving capacity available',()=>{
 const state={members:[{id:'a',name:'A',from:0,until:30,skills:['home','drive']},{id:'b',name:'B',from:0,until:30,skills:['home']}],tasks:[
  {id:'pack',title:'Pack',owner:'a',duration:20,deadline:30,skill:'home',priority:3},
  {id:'drive',title:'Drive',owner:'a',duration:20,deadline:30,skill:'drive',priority:3}
 ],history:[]};
 const plan=planHousehold(state,{memberId:'a',delay:0});
 assert.equal(plan.unassigned.length,0);assert.equal(plan.assignments.find(a=>a.taskId==='pack')?.owner,'b');
 assert.equal(plan.assignments.find(a=>a.taskId==='drive')?.owner,'a');
});
test('approved schedule and changed availability survive a JSON reload',()=>{
 const original=initialState(),proposal=planHousehold(original,{memberId:'lena',delay:30});
 const saved=approvePlan(original,proposal,'2026-10-08T05:00:00.000Z');
 const reloaded=stateSchema.parse(JSON.parse(JSON.stringify(saved)));
 assert.deepEqual(reloaded.approvedPlan?.assignments,proposal.assignments);
 assert.equal(reloaded.members.find(m=>m.id==='lena')?.from,480);
 assert.equal(reloaded.tasks.find(t=>t.id==='school')?.owner,'omar');
 assert.equal(original.approvedPlan,null);assert.equal(original.members[0].from,450);
});
test('stale and edited drafts cannot be approved',()=>{
 const original=initialState(),proposal=planHousehold(original,{memberId:'lena',delay:30});
 const changed=initialState();changed.tasks[0].duration=30;
 assert.throws(()=>approvePlan(changed,proposal,'2026-10-08T05:00:00.000Z'),/no longer matches/);
 const edited=structuredClone(proposal);edited.assignments[0].start++;
 assert.throws(()=>approvePlan(original,edited,'2026-10-08T05:00:00.000Z'),/no longer matches/);
});
test('an unresolved task cannot be recorded complete after partial approval',()=>{
 const original=initialState();original.members=original.members.map(m=>({...m,skills:['home']}));
 const proposal=planHousehold(original,{memberId:'lena',delay:0});
 const saved=approvePlan(original,proposal,'2026-10-08T05:00:00.000Z');
 assert.throws(()=>acknowledgeTask(saved,'school'),/unresolved/);
 assert.equal(acknowledgeTask(saved,'cat').tasks.find(t=>t.id==='cat')?.done,true);
});
test('ambiguous or invalid scenario text does not silently change another person',()=>{
 for(const text of ['Someone is 30 minutes late','Lena and Omar are late','Lena is late','Lena is not late','Lena is -30 minutes late','Lena is 1.5 minutes late','Lena is 30 minutes or 45 minutes late'])
  assert.throws(()=>scenarioFromText(text,initialState()));
 assert.deepEqual(scenarioFromText('Omar is unavailable',initialState()),{memberId:'omar',delay:0,unavailable:true});
});
test('duplicate identifiers and nonexistent owners are rejected',()=>{
 const duplicate=initialState();duplicate.tasks[1].id=duplicate.tasks[0].id;
 assert.throws(()=>planHousehold(duplicate,{memberId:'lena',delay:0}));
 const unknown=initialState();unknown.tasks[0].owner='unknown';
 assert.throws(()=>planHousehold(unknown,{memberId:'lena',delay:0}));
});
test('older saved households are normalized without losing their records',()=>{
 const legacy:any=initialState();delete legacy.approvedPlan;legacy.members.forEach((m:any)=>delete m.unavailable);
 const loaded=stateSchema.parse(legacy);assert.equal(loaded.approvedPlan,null);assert.ok(loaded.members.every(m=>m.unavailable===false));
 assert.equal(loaded.tasks.length,4);
});
