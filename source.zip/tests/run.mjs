import {createRequire} from 'node:module';
import {resolve} from 'node:path';
import {mkdirSync,realpathSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const require=createRequire(realpathSync(resolve('node_modules/wrangler/package.json')));
const {buildSync}=require('esbuild');
mkdirSync('.sites-runtime',{recursive:true});
buildSync({entryPoints:['tests/planner.test.ts'],bundle:true,platform:'node',format:'esm',outfile:'.sites-runtime/planner-test.mjs'});
const result=spawnSync(process.execPath,['--test','.sites-runtime/planner-test.mjs'],{stdio:'inherit'});process.exit(result.status??1);
