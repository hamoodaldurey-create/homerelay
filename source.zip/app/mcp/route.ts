import {dispatch,PROTOCOL} from '../../lib/mcp';
export async function POST(request:Request){
 const origin=request.headers.get('origin');if(origin&&origin!==new URL(request.url).origin)return new Response('Origin not allowed',{status:403});
 const protocol=request.headers.get('mcp-protocol-version');if(protocol&&protocol!==PROTOCOL)return new Response('Unsupported protocol version',{status:400});
 const accept=request.headers.get('accept')||'';if(!accept.includes('application/json')||!accept.includes('text/event-stream'))return new Response('Accept must include application/json and text/event-stream',{status:406});
 if(!(request.headers.get('content-type')||'').includes('application/json'))return new Response('JSON required',{status:415});
 const text=await request.text();if(text.length>60000)return new Response('Request too large',{status:413});
 try{const result=dispatch(JSON.parse(text));return result===null?new Response(null,{status:202}):Response.json(result,{headers:{'Cache-Control':'no-store'}});}catch{return Response.json({jsonrpc:'2.0',id:null,error:{code:-32700,message:'Parse error'}},{status:400});}
}
export function GET(request?:Request){if(request?.headers.get('origin')&&request.headers.get('origin')!==new URL(request.url).origin)return new Response('Origin not allowed',{status:403});return new Response('SSE stream not offered; use POST',{status:405,headers:{Allow:'POST'}});}
export function DELETE(request?:Request){if(request?.headers.get('origin')&&request.headers.get('origin')!==new URL(request.url).origin)return new Response('Origin not allowed',{status:403});return new Response('Stateless transport has no sessions',{status:405,headers:{Allow:'POST'}});}
