 'use client';
import {useEffect,useState,useRef} from 'react';
import {House,Clock3,ShieldCheck,Check,RefreshCw,ChevronDown,Activity,MessageCircle,Sun,CheckCheck,ClipboardList} from 'lucide-react';
import {type Household,type Plan,initialState,time,scenarioFromText,stateSchema,handoffDraft} from '../lib/planner';
const clientId=()=>Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('');
type Trace={tool:string;note:string};
type SaveResponse={state:Household;revision:number;error?:string};
type Draft={taskId:string;recipient:string;message:string};
type Operation={action:'approve';plan:Plan}|{action:'acknowledge';taskId:string}|{action:'reset'};
export default function Home(){
 const initialized=useRef(false);
 const [connection,setConnection]=useState('');
 const [state,setState]=useState<Household>(initialState()),[revision,setRevision]=useState(0),[loaded,setLoaded]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const [text,setText]=useState('Lena is 30 minutes late. Can someone take the school run?'),[memberId,setMember]=useState('lena'),[delay,setDelay]=useState(30),[unavailable,setUnavailable]=useState(false);
 const [plan,setPlan]=useState<Plan|null>(null),[trace,setTrace]=useState<Trace[]>([]),[drafts,setDrafts]=useState<{taskId:string;recipient:string;message:string}[]>([]),[applied,setApplied]=useState(false),[tab,setTab]=useState<'today'|'history'|'integration'>('today');
 useEffect(()=>{void fetch('/api/household').then(async r=>{const d=await r.json() as SaveResponse;if(!r.ok)throw new Error(d.error||"Storage unavailable");const saved=stateSchema.parse(d.state);setState(saved);setRevision(d.revision);setPlan(saved.approvedPlan);setApplied(!!saved.approvedPlan);if(saved.approvedPlan)setDrafts(handoffDraft(saved,saved.approvedPlan));setLoaded(true);}).catch(e=>setError(e.message));},[]);
 async function mcp<T>(name:string,args:unknown):Promise<T>{
 if(!initialized.current){
  const headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-11-25'};
  const init=await fetch('/mcp',{method:'POST',headers,body:JSON.stringify({jsonrpc:'2.0',id:clientId(),method:'initialize',params:{protocolVersion:'2025-11-25',capabilities:{},clientInfo:{name:'HomeRelay web simulation',version:'1.0.0'}}})});
  const negotiated=await init.json() as {result?:{protocolVersion:string}};
  if(!init.ok||negotiated.result?.protocolVersion!=='2025-11-25')throw new Error('MCP initialization failed. Please retry.');
  const notified=await fetch('/mcp',{method:'POST',headers,body:JSON.stringify({jsonrpc:'2.0',method:'notifications/initialized'})});
  if(notified.status!==202)throw new Error('MCP initialization acknowledgment failed.');
  initialized.current=true;
 }
 const r=await fetch('/mcp',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-11-25'},body:JSON.stringify({jsonrpc:'2.0',id:clientId(),method:'tools/call',params:{name,arguments:args}})}),d=await r.json() as {error?:{message:string};result?:{isError?:boolean;content?:{text:string}[];structuredContent:T}};if(!r.ok||d.error||d.result?.isError)throw new Error(d.result?.content?.[0]?.text||d.error?.message||'Tool unavailable');if(!d.result)throw new Error("Missing tool result");return d.result.structuredContent;}
 async function propose(fromText=false){
  setBusy(true);setError('');setApplied(false);setTrace([]);setPlan(null);setDrafts([]);
  try {
   const disruption=fromText?scenarioFromText(text,state):{memberId,delay,unavailable};
   setMember(disruption.memberId);setDelay(disruption.delay);setUnavailable(disruption.unavailable);
   const next=await mcp<Plan>('replan_household',{household:state,disruption});
   const handoffs=await mcp<{handoffs:Draft[]}>('draft_handoffs',{household:state,disruption});
   setPlan(next);setDrafts(handoffs.handoffs);
   setTrace([{tool:'replan_household',note:`${next.assignments.length} tasks fit; ${next.unassigned.length} remain unresolved. Availability, capabilities, deadlines, and overlaps checked.`},
    {tool:'draft_handoffs',note:`${handoffs.handoffs.length} requests drafted with exact times. Nothing has been sent.`}]);
  } catch(failure){setPlan(state.approvedPlan);setApplied(!!state.approvedPlan);setDrafts(state.approvedPlan?handoffDraft(state,state.approvedPlan):[]);setError(failure instanceof Error?failure.message:'Please retry.');}
  finally{setBusy(false);}
 }
 async function persist(operation:Operation){
  const response=await fetch('/api/household',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...operation,revision})});
  const result=await response.json() as SaveResponse;
  if(!response.ok)throw new Error(result.error||'Unable to save');
  const saved=stateSchema.parse(result.state);setState(saved);setRevision(result.revision);return saved;
 }
 async function approve(){
  if(!plan)return;setBusy(true);setError('');
  try{const saved=await persist({action:'approve',plan});setPlan(saved.approvedPlan);setApplied(true);setText('');setDelay(0);setUnavailable(false);}
  catch(failure){setError((failure as Error).message);}finally{setBusy(false);}
 }
 async function acknowledge(taskId:string){
  setBusy(true);setError('');
  try{await persist({action:'acknowledge',taskId});}
  catch(failure){setError((failure as Error).message);}finally{setBusy(false);}
 }
 async function reset(){
  setBusy(true);setError('');
  try{await persist({action:'reset'});setPlan(null);setTrace([]);setDrafts([]);setApplied(false);setText('Lena is 30 minutes late. Can someone take the school run?');setMember('lena');setDelay(30);setUnavailable(false);}
  catch(failure){setError((failure as Error).message);}finally{setBusy(false);}
 }
 function discardDraft(){setPlan(state.approvedPlan);setApplied(!!state.approvedPlan);setDrafts(state.approvedPlan?handoffDraft(state,state.approvedPlan):[]);setTrace([]);setError('');}
 async function verifyConnection(){
  setBusy(true);setConnection('Checking the MCP connection…');setError('');
  try{
   const sample=await mcp<Household>('get_demo_household',{});
   const draft=await mcp<Plan>('replan_household',{household:sample,disruption:{memberId:'lena',delay:30,unavailable:false}});
   if(draft.assignments.length!==sample.tasks.length||draft.unassigned.length)throw new Error('Sample planning check failed.');
   setConnection(`Connection verified. Initialization and live sample tool calls succeeded: ${draft.assignments.length} tasks fit, ${draft.changes} handoffs.`);
  }catch(failure){setConnection('Connection check failed. Please retry.');setError((failure as Error).message);}finally{setBusy(false);}
 }
 useEffect(()=>{const context=(document as unknown as {modelContext?:{registerTool:(tool:unknown,options:unknown)=>unknown}}).modelContext;if(!context)return;const lifecycle=new AbortController();try{void Promise.resolve(context.registerTool({name:'read_household_plan',description:'Read the visible household and draft plan without changing it.',inputSchema:{type:'object',additionalProperties:false},annotations:{readOnlyHint:true,untrustedContentHint:true},execute:(input:unknown)=>{if(!input||Object.keys(input as object).length)throw new Error('No arguments accepted');return {tasks:state.tasks,plan,approved:applied};}},{signal:lifecycle.signal})).catch(()=>{});}catch{}return()=>lifecycle.abort();},[state,plan,applied]);
 return <main><header><a className="brand" href="/"><span className="brandmark"><House size={23}/></span>HomeRelay<span className="beta">LAB</span></a><nav aria-label="Main navigation"><button className={tab==='today'?'active':''} onClick={()=>setTab('today')}>Today</button><button className={tab==='history'?'active':''} onClick={()=>setTab('history')}>Activity</button><button className={tab==='integration'?'active':''} onClick={()=>setTab('integration')}>MCP connection</button></nav><span className="avatar">HA</span></header>
 <div className="workspace"><aside className="household"><div className="eyebrow">YOUR HOUSEHOLD</div><h2>The morning crew</h2><p className="muted">A fictional household in your own saved workspace.</p>{state.members.map(m=><div className="member" key={m.id}><span className={`member-avatar ${m.id}`}>{m.name[0]}</span><div><strong>{m.name}</strong><small>{m.unavailable?'Unavailable':`${time(m.from)}–${time(m.until)}`}</small></div><span className="capability">{m.skills.includes('drive')?'Driver':'Home'}</span></div>)}<div className="aside-note"><ShieldCheck size={22}/><strong>People stay in control</strong><p>Plans are drafts until approved. Acknowledgments are recorded inside this demo.</p></div><button className="reset" onClick={reset} disabled={busy||!loaded}><RefreshCw size={15}/>Reset demo household</button><small className="persistence">{loaded?'Saved in your own demo workspace':'Connecting to storage…'}</small></aside>
 <section className="content">{tab==='today'?<><div className="welcome"><div><div className="eyebrow">A LITTLE LESS MENTAL LOAD</div><h1>Keep the morning moving.</h1><p>Check the options, approve the handoffs, and keep a shared record.</p></div><div className="sunrise" aria-hidden="true"><Sun size={45}/><span>07:30</span><small>A fresh start</small></div></div>
 <div className="banner"><span className="pill"><MessageCircle size={14}/> Alexa+ web simulation</span><span>Real MCP tools · synthetic household · no device connection</span></div>
 {error&&<div role="alert" className="error">{error}</div>}<div className="two-columns"><div><section className="panel assistant"><div className="panel-title"><span className="icon"><Activity size={19}/></span><div><h2>Tell us what changed</h2><p>A practical plan, with the reasoning visible.</p></div></div><label htmlFor="request">Household update</label><textarea id="request" value={text} onChange={e=>setText(e.target.value)} rows={3} placeholder="For example: Omar is unavailable" maxLength={500} disabled={busy}/><button className="primary wide" onClick={()=>propose(true)} disabled={busy||!loaded}>{busy?'Planning…':'Find a workable plan'}</button><div className="or">or set availability</div><div className="controls"><label>Person<select disabled={busy} value={memberId} onChange={e=>setMember(e.target.value)}>{state.members.map(m=><option key={m.id} value={m.id}>{m.name}</option>)}</select></label><label>Additional delay (minutes)<input disabled={busy} type="number" min="0" max="240" value={delay} onChange={e=>setDelay(Number(e.target.value))}/></label></div><label className="check"><input type="checkbox" disabled={busy} checked={unavailable} onChange={e=>setUnavailable(e.target.checked)}/>Unavailable for this update</label><button className="secondary wide" onClick={()=>propose()} disabled={busy||!loaded}>Replan with these constraints</button><p className="small">Use one person’s name and a delay in minutes, or say they are unavailable. This is an explicit-scenario simulation.</p></section>
 {trace.length>0&&<section className="panel trace"><h3><ClipboardList size={18}/> What the tools did</h3>{trace.map((t,i)=><div className="trace-row" key={t.tool}><span>{i+1}</span><div><code>{t.tool}</code><p>{t.note}</p></div><Check size={15}/></div>)}</section>}</div>
 <section className="panel schedule"><div className="panel-title"><span className="icon"><Clock3 size={19}/></span><div><h2>{plan?(applied?'Your approved morning':'Your proposed morning'):'Today’s essentials'}</h2><p>{state.tasks.filter(t=>t.done).length} of {state.tasks.length} acknowledged</p></div></div>{plan&&<div className={`plan-summary ${plan.unassigned.length?'warning':''}`}><ShieldCheck size={20}/><p>{plan.summary}</p></div>} {plan&&<div className="plan-metrics" aria-label="Plan results"><div><strong>{plan.assignments.length}</strong><span>Tasks fit</span></div><div><strong>{plan.changes}</strong><span>Handoffs</span></div><div className={plan.unassigned.length?'attention':''}><strong>{plan.unassigned.length}</strong><span>Need attention</span></div></div>}<div className="tasks">{state.tasks.map(task=>{const a=plan?.assignments.find(a=>a.taskId===task.id),unresolved=plan?.unassigned.find(a=>a.taskId===task.id),owner=state.members.find(m=>m.id===(a?.owner||task.owner));return <article className={`task ${task.done?'done':''}`} key={task.id}><div className="task-time">{unresolved?'Unresolved':a?`${time(a.start)}–${time(a.end)}`:time(task.deadline-task.duration)}<small>{task.duration} min</small></div><div className="task-detail"><h3>{task.title}</h3><p>{owner?.name} <span>· finish by {time(task.deadline)}</span></p>{a?.changed&&<span className="tag">{applied?'Handoff approved':'Handoff proposed'}</span>}{unresolved&&<p className="unresolved">{unresolved.reason}</p>}{a&&<details><summary>Why this works <ChevronDown size={12}/></summary><p>{a.reason}</p></details>}</div>{task.done?<CheckCheck className="completed" size={23}/>:<button className="task-check" aria-label={`Acknowledge ${task.title} complete`} title="Record a demo acknowledgment" onClick={()=>acknowledge(task.id)} disabled={busy||!loaded||!!unresolved||!!plan&&!applied}><Check size={17}/></button>}</article>;})}</div>{plan&&!applied&&<><button className="primary wide" onClick={approve} disabled={busy||!loaded||!plan.assignments.length}>Approve workable schedule</button><button className="secondary wide" onClick={discardDraft} disabled={busy}>Discard draft</button></>}{applied&&<div className="approved"><CheckCheck size={18}/> Schedule and availability saved. Acknowledgments are ready.</div>}<p className="small">{plan?'Unresolved tasks stay open. Approval saves times, owners, and availability; handoff requests stay inside this demo.':'Replan to check availability and overlapping tasks.'}</p></section></div>
 {drafts.length>0&&<section className="panel handoffs"><h2>Ready for a clear handoff</h2><p className="muted">Draft requests for your household. No message has been sent.</p><div className="draft-grid">{drafts.map(d=><article key={d.taskId}><span className="tag">{applied?'Approved in app':'Draft'}</span><h3>To {d.recipient}</h3><p>{d.message}</p></article>)}</div></section>}</>:tab==='history'?<section className="panel"><div className="eyebrow">THE SHARED RECORD</div><h1>Activity, without the guessing.</h1>{state.history.length?state.history.map(h=><div className="history-row" key={h.id}><CheckCheck size={20}/><div><p>{h.text}</p><small>{new Date(h.at).toLocaleString()}</small></div></div>):<p className="muted">Approve a plan or acknowledge a task to start your activity record.</p>}</section>:<section className="panel integration"><div className="eyebrow">BUILT ON AN OPEN STANDARD</div><h1>A household toolset<br/>your agent can understand.</h1><p>MCP 2025-11-25 over stateless Streamable HTTP. Connect an MCP-compatible client to this site’s <code>/mcp</code> endpoint.</p><div className="code-block">POST /mcp<br/>Accept: application/json, text/event-stream<br/>MCP-Protocol-Version: 2025-11-25</div><button className="primary" onClick={verifyConnection} disabled={busy}>{busy?'Checking…':'Verify MCP connection'}</button>{connection&&<p role="status" className="connection-status">{connection}</p>}<h2>Three focused tools</h2><ul><li><code>get_demo_household</code> reads synthetic sample data.</li><li><code>replan_household</code> computes a feasible draft schedule.</li><li><code>draft_handoffs</code> prepares acknowledgment requests.</li></ul><p className="small">Tools accept caller-supplied context and produce drafts. They cannot read saved private household data or commit changes. Actual Alexa+ account/device connection and LLM interpretation are future integration work.</p></section>}
 <footer>HomeRelay · built for the Amazon Developer Hackathon · {loaded?'Persistent demo workspace':'Storage not connected'}</footer></section></div></main>;
}
