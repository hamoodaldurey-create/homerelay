import {database, identity} from '../../../lib/storage';
import {initialState, stateSchema, approvePlan, acknowledgeTask, type Household} from '../../../lib/planner';

export async function GET(request: Request) {
  try {
    const who = identity(request), db = database();
    await db.prepare('INSERT OR IGNORE INTO households (id,body,revision,updated_at) VALUES (?,?,0,?)')
      .bind(who.id, JSON.stringify(initialState()), new Date().toISOString()).run();
    const row = await db.prepare('SELECT body,revision FROM households WHERE id=?').bind(who.id).first<{body: string; revision: number}>();
    if (!row) throw new Error('Household unavailable');
    return Response.json({state: stateSchema.parse(JSON.parse(row.body)), revision: row.revision}, {
      headers: {'Cache-Control': 'no-store', ...(who.cookie ? {'Set-Cookie': who.cookie} : {})},
    });
  } catch {return Response.json({error: 'Storage is currently unavailable. Please retry.'}, {status: 503});}
}

export async function POST(request: Request) {
  if (request.headers.get('origin') !== new URL(request.url).origin) return Response.json({error: 'Origin not allowed'}, {status: 403});
  if (!(request.headers.get('content-type') || '').includes('application/json')) return Response.json({error: 'JSON required'}, {status: 415});
  const who = identity(request);
  if (who.cookie) return Response.json({error: 'Load the household first.'}, {status: 401});
  let input: {action?: string; revision?: number; plan?: unknown; taskId?: string};
  try {
    const text = await request.text();
    if (text.length > 50000) return Response.json({error: 'Request too large'}, {status: 413});
    input = JSON.parse(text);
    if (!input || !Number.isInteger(input.revision) || input.revision! < 0) throw new Error('Invalid revision');
  } catch {return Response.json({error: 'Invalid request. Your draft is preserved.'}, {status: 400});}
  let current: Household, currentRevision: number;
  try {
    const row = await database().prepare('SELECT body,revision FROM households WHERE id=?').bind(who.id).first<{body: string; revision: number}>();
    if (!row) return Response.json({error: 'Load the household first.'}, {status: 401});
    current = stateSchema.parse(JSON.parse(row.body)); currentRevision = row.revision;
  } catch {return Response.json({error: 'Storage is currently unavailable. Your draft is preserved.'}, {status: 503});}
  if (currentRevision !== input.revision) return Response.json({error: 'The household changed in another tab. Reload before applying this plan.'}, {status: 409});
  let next: Household;
  const at = new Date().toISOString();
  try {
    if (input.action === 'approve') {
      next = approvePlan(current, input.plan, at);
      next.history = [{id: crypto.randomUUID(), at, text: `Approved schedule: ${next.approvedPlan!.assignments.length} tasks fit, ${next.approvedPlan!.changes} handoffs, ${next.approvedPlan!.unassigned.length} unresolved.`}, ...current.history].slice(0, 100);
    } else if (input.action === 'acknowledge' && typeof input.taskId === 'string') {
      next = acknowledgeTask(current, input.taskId);
      const task = next.tasks.find(item => item.id === input.taskId)!;
      if (!current.tasks.find(item => item.id === input.taskId)?.done)
        next.history = [{id: crypto.randomUUID(), at, text: `${task.title} acknowledged complete by ${next.members.find(member => member.id === task.owner)?.name} in this demo.`}, ...current.history].slice(0, 100);
    } else if (input.action === 'reset') next = initialState();
    else throw new Error('Choose a supported household action.');
  } catch (failure) {
    return Response.json({error: failure instanceof Error ? failure.message : 'Invalid household action'}, {status: 400});
  }
  try {
    const result = await database().prepare('UPDATE households SET body=?,revision=revision+1,updated_at=? WHERE id=? AND revision=?')
      .bind(JSON.stringify(next), at, who.id, input.revision).run();
    if (!result.meta.changes) return Response.json({error: 'The household changed in another tab. Reload before applying this plan.'}, {status: 409});
    return Response.json({state: next, revision: input.revision! + 1}, {headers: {'Cache-Control': 'no-store'}});
  } catch {return Response.json({error: 'Unable to save. Your draft is preserved; please retry.'}, {status: 503});}
}
