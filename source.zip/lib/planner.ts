import { z } from 'zod';

const identifier = z.string().min(1).max(40);
const minute = z.number().int().min(0).max(1440);
export const memberSchema = z.object({
  id: identifier, name: z.string().min(1).max(40), from: minute, until: minute,
  skills: z.array(z.string().min(1).max(30)).max(10), unavailable: z.boolean().default(false),
}).refine(member => member.until >= member.from, 'Availability must end after it starts.');
export const taskSchema = z.object({
  id: identifier, title: z.string().min(1).max(100), owner: identifier,
  duration: z.number().int().min(1).max(120), deadline: minute,
  skill: z.string().min(1).max(30), priority: z.number().int().min(1).max(3), done: z.boolean().default(false),
});
export const disruptionSchema = z.object({memberId: identifier, delay: z.number().int().min(0).max(240), unavailable: z.boolean().default(false)});
const assignmentSchema = z.object({
  taskId: identifier, owner: identifier, start: minute, end: minute,
  changed: z.boolean(), reason: z.string().max(500),
}).refine(assignment => assignment.end > assignment.start, 'An assignment needs a positive duration.');
export const planSchema = z.object({
  assignments: z.array(assignmentSchema).max(30),
  unassigned: z.array(z.object({taskId: identifier, reason: z.string().max(500)})).max(30),
  changes: z.number().int().min(0).max(30), summary: z.string().max(500), disruption: disruptionSchema,
});
const savedPlanSchema = planSchema.extend({approvedAt: z.string().datetime()});
export const stateSchema = z.object({
  members: z.array(memberSchema).min(1).max(8), tasks: z.array(taskSchema).max(30),
  history: z.array(z.object({id: z.string().max(80), at: z.string().max(50), text: z.string().max(500)})).max(100),
  approvedPlan: savedPlanSchema.nullable().default(null),
}).superRefine((state, context) => {
  if (new Set(state.members.map(member => member.id)).size !== state.members.length)
    context.addIssue({code: z.ZodIssueCode.custom, message: 'Household member IDs must be unique.'});
  if (new Set(state.tasks.map(task => task.id)).size !== state.tasks.length)
    context.addIssue({code: z.ZodIssueCode.custom, message: 'Task IDs must be unique.'});
  if (state.tasks.some(task => !state.members.some(member => member.id === task.owner)))
    context.addIssue({code: z.ZodIssueCode.custom, message: 'Every task needs a known household owner.'});
});
export type Household = z.infer<typeof stateSchema>;
export type Assignment = z.infer<typeof assignmentSchema>;
export type Plan = z.infer<typeof planSchema>;
export type Disruption = z.infer<typeof disruptionSchema>;
export const time = (value: number) => `${String(Math.floor(value / 60)).padStart(2, '0')}:${String(value % 60).padStart(2, '0')}`;

export function initialState(): Household {
  return {
    members: [
      {id: 'lena', name: 'Lena', from: 450, until: 540, skills: ['drive', 'home'], unavailable: false},
      {id: 'omar', name: 'Omar', from: 465, until: 520, skills: ['drive', 'home'], unavailable: false},
      {id: 'ivy', name: 'Ivy', from: 450, until: 480, skills: ['home'], unavailable: false},
    ],
    tasks: [
      {id: 'school', title: 'School run', owner: 'lena', duration: 25, deadline: 495, skill: 'drive', priority: 3, done: false},
      {id: 'lunch', title: 'Pack lunch & backpack', owner: 'lena', duration: 10, deadline: 470, skill: 'home', priority: 3, done: false},
      {id: 'cat', title: 'Feed the cat', owner: 'ivy', duration: 5, deadline: 480, skill: 'home', priority: 2, done: false},
      {id: 'parcel', title: 'Drop off the parcel', owner: 'omar', duration: 10, deadline: 515, skill: 'drive', priority: 1, done: false},
    ],
    history: [], approvedPlan: null,
  };
}

function changedMembers(state: Household, change: Disruption): Household['members'] {
  if (!state.members.some(member => member.id === change.memberId)) throw new Error('Choose a household member.');
  return state.members.map(member => member.id !== change.memberId ? {...member} : {
    ...member, from: Math.min(member.until, member.from + change.delay),
    unavailable: change.unavailable || member.from + change.delay >= member.until,
  });
}

// Both ends of a free interval matter: a later placement can preserve an
// earlier slot for another task with a tighter deadline.
function freeStarts(member: Household['members'][number], task: Household['tasks'][number], assignments: Assignment[]): number[] {
  if (member.unavailable || !member.skills.includes(task.skill)) return [];
  const limit = Math.min(task.deadline, member.until);
  const booked = assignments.filter(assignment => assignment.owner === member.id).sort((a, b) => a.start - b.start);
  const starts = new Set<number>();
  let cursor = member.from;
  for (const interval of [...booked, {start: limit, end: limit}]) {
    const end = Math.min(limit, interval.start);
    if (end - cursor >= task.duration) { starts.add(cursor); starts.add(end - task.duration); }
    cursor = Math.max(cursor, interval.end);
    if (cursor > limit) break;
  }
  return [...starts];
}

type Candidate = {assignments: Assignment[]; score: number[]; changes: number; finish: number};
function comparePlans(left: Candidate, right: Candidate) {
  return right.score[3] - left.score[3] || right.score[2] - left.score[2] || right.score[1] - left.score[1]
    || left.changes - right.changes || left.finish - right.finish;
}

export function planHousehold(raw: unknown, disruption: unknown): Plan {
  const state = stateSchema.parse(raw), change = disruptionSchema.parse(disruption);
  const members = changedMembers(state, change);
  const tasks = state.tasks.filter(task => !task.done).sort((a, b) => b.priority - a.priority || a.deadline - b.deadline || b.duration - a.duration);
  let beam: Candidate[] = [{assignments: [], score: [0, 0, 0, 0], changes: 0, finish: 0}];
  // Bounded search gives predictable edge-runtime work. It explores owner
  // and timing alternatives without claiming global optimality.
  for (const task of tasks) {
    const next: Candidate[] = [];
    for (const candidate of beam) {
      next.push(candidate);
      for (const member of members) {
        for (const start of freeStarts(member, task, candidate.assignments)) {
          const changed = member.id !== task.owner, end = start + task.duration;
          const score = [...candidate.score]; score[task.priority]++;
          next.push({assignments: [...candidate.assignments, {
            taskId: task.id, owner: member.id, start, end, changed,
            reason: `${member.name} is available ${time(member.from)}–${time(member.until)}, has the required ${task.skill} capability, and can finish by ${time(task.deadline)} without overlapping another task.`,
          }], score, changes: candidate.changes + Number(changed), finish: candidate.finish + end});
        }
      }
    }
    beam = next.sort(comparePlans).slice(0, 48);
  }
  const best = beam[0], assignments = best.assignments.sort((a, b) => a.start - b.start || a.taskId.localeCompare(b.taskId));
  const unassigned = tasks.filter(task => !assignments.some(assignment => assignment.taskId === task.id)).map(task => ({
    taskId: task.id,
    reason: members.some(member => !member.unavailable && member.skills.includes(task.skill))
      ? `No free ${task.duration}-minute ${task.skill} slot fits before ${time(task.deadline)} in this plan. Adjust availability or the deadline; this task remains unresolved.`
      : `No available household member has the required ${task.skill} capability. This task remains unresolved.`,
  }));
  const changes = best.changes;
  return {assignments, unassigned, changes, disruption: change,
    summary: unassigned.length ? `${assignments.length} tasks fit. ${unassigned.length} task${unassigned.length === 1 ? '' : 's'} still need your attention.`
      : changes ? `All ${assignments.length} tasks fit. ${changes} handoff${changes === 1 ? '' : 's'} need your approval.`
        : `All ${assignments.length} tasks fit. Everyone can keep their tasks.`,
  };
}

export function approvePlan(raw: unknown, proposal: unknown, approvedAt: string): Household {
  const state = stateSchema.parse(raw), plan = planSchema.parse(proposal);
  const verified = planSchema.parse(planHousehold(state, plan.disruption));
  if (JSON.stringify(plan) !== JSON.stringify(verified)) throw new Error('The draft no longer matches this household. Replan before approving.');
  if (!plan.assignments.length) throw new Error('There are no workable assignments to approve.');
  return stateSchema.parse({...state, members: changedMembers(state, plan.disruption),
    tasks: state.tasks.map(task => ({...task, owner: plan.assignments.find(assignment => assignment.taskId === task.id)?.owner || task.owner})),
    approvedPlan: {...plan, approvedAt},
  });
}

export function acknowledgeTask(raw: unknown, taskId: string): Household {
  const state = stateSchema.parse(raw), task = state.tasks.find(task => task.id === taskId);
  if (!task) throw new Error('Choose a known task.');
  if (state.approvedPlan?.unassigned.some(unassigned => unassigned.taskId === taskId))
    throw new Error('This task is unresolved. Find a workable assignment before acknowledging it.');
  return {...state, tasks: state.tasks.map(item => item.id === taskId ? {...item, done: true} : item)};
}

export function handoffDraft(raw: unknown, plan: Plan) {
  const state = stateSchema.parse(raw);
  return plan.assignments.filter(assignment => assignment.changed).map(assignment => {
    const task = state.tasks.find(task => task.id === assignment.taskId), member = state.members.find(member => member.id === assignment.owner);
    if (!task || !member) throw new Error('The draft contains an unknown task or member.');
    return {taskId: assignment.taskId, recipient: member.name, message: `${member.name}, can you take “${task.title}” from ${time(assignment.start)} to ${time(assignment.end)}? Please acknowledge in HomeRelay.`, status: 'draft'};
  });
}

export function scenarioFromText(text: string, state: Household): Disruption {
  const clean = text.toLowerCase().replace(/[’‘]/g, "'");
  const named = state.members.filter(member => new RegExp(`\\b${member.name.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`).test(clean));
  if (named.length !== 1) throw new Error('Name one household member, for example “Lena is 30 minutes late”, or use the availability controls.');
  if (/\b(?:not|isn't|isnt)\s+(?:late|delayed|unavailable)\b/.test(clean)) throw new Error('Use the availability controls to confirm that someone is available.');
  const unavailable = /\b(?:unavailable|can't|cannot|not available)\b/.test(clean);
  const delays = [...clean.matchAll(/(-?\d+(?:\.\d+)?)\s*(?:minutes?|mins?)\b/g)];
  if (delays.length > 1) throw new Error('Use one delay per update, or use the availability controls.');
  const minutes = delays[0]?.[1];
  if (!unavailable && (!/\b(?:late|delay|delayed)\b/.test(clean) || minutes === undefined))
    throw new Error('Include a delay in minutes, or say “Omar is unavailable”. This simulation supports explicit availability updates.');
  return disruptionSchema.parse({memberId: named[0].id, delay: unavailable ? 0 : Number(minutes), unavailable});
}
