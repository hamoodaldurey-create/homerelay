import { z } from 'zod';
export const memberSchema=z.object({id:z.string().max(40),name:z.string().max(40),from:z.number().int().min(0).max(1440),until:z.number().int().min(0).max(1440),skills:z.array(z.string().max(30)).max(10)});
export const taskSchema=z.object({id:z.string().max(40),title:z.string().max(100),owner:z.string().max(40),duration:z.number().int().min(1).max(120),deadline:z.number().int().min(0).max(1440),skill:z.string().max(30),priority:z.number().int().min(1).max(3),done:z.boolean().default(false)});
export const stateSchema=z.object({members:z.array(memberSchema).min(1).max(8),tasks:z.array(taskSchema).max(30),history:z.array(z.object({id:z.string(),at:z.string(),text:z.string().max(500)})).max(100)});
export type Household=z.infer<typeof stateSchema>;
export type Assignment={taskId:string;owner:string;start:number;end:number;changed:boolean;reason:string};
export type Plan={assignments:Assignment[];unassigned:{taskId:string;reason:string}[];changes:number;summary:string};
export const time=(n:number)=>`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
export function initialState():Household{return {members:[{id:'lena',name:'Lena',from:450,until:540,skills:['drive','home']},{id:'omar',name:'Omar',from:465,until:520,skills:['drive','home']},{id:'ivy',name:'Ivy',from:450,until:480,skills:['home']}],tasks:[{id:'school',title:'School run',owner:'lena',duration:25,deadline:495,skill:'drive',priority:3,done:false},{id:'lunch',title:'Pack lunch & backpack',owner:'lena',duration:10,deadline:470,skill:'home',priority:3,done:false},{id:'cat',title:'Feed the cat',owner:'ivy',duration:5,deadline:480,skill:'home',priority:2,done:false},{id:'parcel',title:'Drop off the parcel',owner:'omar',duration:10,deadline:515,skill:'drive',priority:1,done:false}],history:[]};}
export const disruptionSchema=z.object({memberId:z.string().max(40),delay:z.number().int().min(0).max(240),unavailable:z.boolean().default(false)});
export function planHousehold(raw:unknown, disruption:unknown):Plan{
 const state=stateSchema.parse(raw),change=disruptionSchema.parse(disruption);
 if(!state.members.some(m=>m.id===change.memberId))throw new Error('Choose a household member.');
 const members=state.members.map(m=>({...m,from:m.id===change.memberId?m.from+change.delay:m.from,until:m.id===change.memberId&&change.unavailable?0:m.until}));
 const booked=new Map<string,{start:number;end:number}[]>(),assignments:Assignment[]=[],unassigned:Plan['unassigned']=[];
 const tasks=state.tasks.filter(t=>!t.done).sort((a,b)=>b.priority-a.priority||a.deadline-b.deadline||b.duration-a.duration);
 for(const task of tasks){
  const candidates=members.filter(m=>m.skills.includes(task.skill)).flatMap(m=>{const intervals=booked.get(m.id)||[];for(let start=Math.max(450,m.from);start+task.duration<=Math.min(task.deadline,m.until);start++){const end=start+task.duration;if(!intervals.some(i=>start<i.end&&end>i.start))return [{member:m,start,end,score:(m.id===task.owner?0:100)+start/1440}];}return [];}).sort((a,b)=>a.score-b.score);
  const c=candidates[0];if(!c){unassigned.push({taskId:task.id,reason:`No available member with ${task.skill} capacity can finish by ${time(task.deadline)}. Change the deadline or availability.`});continue;}
  booked.set(c.member.id,[...(booked.get(c.member.id)||[]),{start:c.start,end:c.end}]);assignments.push({taskId:task.id,owner:c.member.id,start:c.start,end:c.end,changed:c.member.id!==task.owner,reason:c.member.id===task.owner?'Original owner can still finish before the deadline.':`${c.member.name} has the required ${task.skill} capability and a free ${task.duration}-minute slot.`});
 }
 const changes=assignments.filter(a=>a.changed).length;
 return {assignments:assignments.sort((a,b)=>a.start-b.start),unassigned,changes,summary:unassigned.length?`${unassigned.length} task${unassigned.length===1?'':'s'} still need your attention. No impossible schedule has been confirmed.`:changes?`A workable morning is ready. ${changes} handoff${changes===1?'':'s'} need your approval.`:'Everyone can keep their tasks. The updated schedule fits.'};
}
export function handoffDraft(raw:unknown,plan:Plan){const state=stateSchema.parse(raw);return plan.assignments.filter(a=>a.changed).map(a=>{const t=state.tasks.find(t=>t.id===a.taskId)!,m=state.members.find(m=>m.id===a.owner)!;return {taskId:a.taskId,recipient:m.name,message:`${m.name}, can you take “${t.title}” from ${time(a.start)} to ${time(a.end)}? Please acknowledge in HomeRelay.`,status:'draft'};});}
export function scenarioFromText(text:string,state:Household){const clean=text.toLowerCase(),member=state.members.find(m=>clean.includes(m.name.toLowerCase()))||state.members[0],minutes=clean.match(/(\d{1,3})\s*(?:min|minutes)/)?.[1];if(!/(late|delay|unavailable|can't|cannot|not available)/.test(clean))throw new Error('Try “Lena is 30 minutes late” or use the availability controls. This demo uses explicit scenarios rather than an LLM.');return {memberId:member.id,delay:minutes?Number(minutes):30,unavailable:/(unavailable|can't|cannot|not available)/.test(clean)};}
