import {initialState,planHousehold,handoffDraft,stateSchema,disruptionSchema} from './planner';
export const PROTOCOL='2025-11-25';
const householdJSON={type:'object',properties:{members:{type:'array',items:{type:'object'}},tasks:{type:'array',items:{type:'object'}},history:{type:'array',items:{type:'object'}}},required:['members','tasks','history']};
const disruptionJSON={type:'object',properties:{memberId:{type:'string'},delay:{type:'integer',minimum:0,maximum:240},unavailable:{type:'boolean'}},required:['memberId','delay']};
export const tools=[
{name:'get_demo_household',title:'Get demo household',description:'Read a fictional household. No personal or device data is exposed.',inputSchema:{type:'object',additionalProperties:false},annotations:{readOnlyHint:true,destructiveHint:false,openWorldHint:false}},
{name:'replan_household',title:'Replan household',description:'Calculate a conflict-free draft schedule from caller-supplied context. Does not commit changes.',inputSchema:{type:'object',properties:{household:householdJSON,disruption:disruptionJSON},required:['household','disruption'],additionalProperties:false},annotations:{readOnlyHint:true,destructiveHint:false,openWorldHint:false}},
{name:'draft_handoffs',title:'Draft handoffs',description:'Draft acknowledgment requests. Does not send messages or save assignments.',inputSchema:{type:'object',properties:{household:householdJSON,disruption:disruptionJSON},required:['household','disruption'],additionalProperties:false},annotations:{readOnlyHint:true,destructiveHint:false,openWorldHint:false}}];
export function dispatch(message:unknown):unknown|null{
 if(!message||typeof message!=='object'||Array.isArray(message))return {jsonrpc:'2.0',id:null,error:{code:-32600,message:'Invalid request'}};
 const m=message as {jsonrpc?:string;id?:string|number;method?:string;params?:Record<string,unknown>};
 if(m.jsonrpc!=='2.0'||typeof m.method!=='string')return {jsonrpc:'2.0',id:m.id??null,error:{code:-32600,message:'Invalid request'}};
 if(m.id===undefined)return null;
 const result=(value:unknown)=>({jsonrpc:'2.0',id:m.id,result:value}),error=(code:number,text:string)=>({jsonrpc:'2.0',id:m.id,error:{code,message:text}});
 if(m.method==='initialize')return result({protocolVersion:PROTOCOL,capabilities:{tools:{listChanged:false}},serverInfo:{name:'HomeRelay',version:'1.0.0'},instructions:'Tools calculate drafts. People approve and acknowledge changes in the app. The web interface is an Alexa+ simulation; no Alexa connection is claimed.'});
 if(m.method==='ping')return result({});if(m.method==='tools/list')return result({tools});if(m.method!=='tools/call')return error(-32601,'Method not found');
 const args=(m.params?.arguments||{}) as Record<string,unknown>,name=m.params?.name;
 try{let data:unknown;if(name==='get_demo_household')data=initialState();else if(name==='replan_household')data=planHousehold(args.household,args.disruption);else if(name==='draft_handoffs')data={handoffs:handoffDraft(stateSchema.parse(args.household),planHousehold(args.household,disruptionSchema.parse(args.disruption)))};else return error(-32602,'Unknown tool');return result({content:[{type:'text',text:JSON.stringify(data)}],structuredContent:data,isError:false});}catch(e){return result({content:[{type:'text',text:e instanceof Error?e.message:'Invalid arguments'}],isError:true});}
}
