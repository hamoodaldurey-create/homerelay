import {initialState, planHousehold, handoffDraft, stateSchema, disruptionSchema} from './planner';
export const PROTOCOL = '2025-11-25';
const id = {type: 'string', minLength: 1, maxLength: 40};
const minute = {type: 'integer', minimum: 0, maximum: 1440};
const disruptionJSON = {type: 'object', properties: {
  memberId: id, delay: {type: 'integer', minimum: 0, maximum: 240}, unavailable: {type: 'boolean', default: false},
}, required: ['memberId', 'delay'], additionalProperties: false};
const householdJSON = {type: 'object', properties: {
  members: {type: 'array', minItems: 1, maxItems: 8, items: {type: 'object', properties: {
    id, name: {type: 'string', minLength: 1, maxLength: 40}, from: {...minute, description: 'Availability starts, in minutes after midnight.'},
    until: {...minute, description: 'Availability ends, in minutes after midnight.'},
    skills: {type: 'array', maxItems: 10, items: {type: 'string', minLength: 1, maxLength: 30}}, unavailable: {type: 'boolean', default: false},
  }, required: ['id', 'name', 'from', 'until', 'skills'], additionalProperties: false}},
  tasks: {type: 'array', maxItems: 30, items: {type: 'object', properties: {
    id, title: {type: 'string', minLength: 1, maxLength: 100}, owner: id, duration: {type: 'integer', minimum: 1, maximum: 120},
    deadline: minute, skill: {type: 'string', minLength: 1, maxLength: 30}, priority: {type: 'integer', minimum: 1, maximum: 3, description: '3 essential, 2 routine, 1 flexible.'}, done: {type: 'boolean', default: false},
  }, required: ['id', 'title', 'owner', 'duration', 'deadline', 'skill', 'priority'], additionalProperties: false}},
  history: {type: 'array', maxItems: 100, items: {type: 'object', properties: {id: {type: 'string', maxLength: 80}, at: {type: 'string', maxLength: 50}, text: {type: 'string', maxLength: 500}}, required: ['id', 'at', 'text'], additionalProperties: false}},
  approvedPlan: {type: ['object', 'null'], description: 'An optional previously approved schedule returned by the app. Planner tools never save or modify it.'},
}, required: ['members', 'tasks', 'history'], additionalProperties: false};
const draftInput = {type: 'object', properties: {household: householdJSON, disruption: disruptionJSON}, required: ['household', 'disruption'], additionalProperties: false};
const readonly = {readOnlyHint: true, destructiveHint: false, openWorldHint: false};
export const tools = [
  {name: 'get_demo_household', title: 'Get demo household', description: 'Read a fictional sample household with availability windows and prioritized tasks. No personal or device data is exposed.', inputSchema: {type: 'object', additionalProperties: false}, annotations: readonly},
  {name: 'replan_household', title: 'Replan household', description: 'Explore bounded owner/timing alternatives and calculate a draft without overlaps, missed deadlines, or missing capabilities. Essential tasks take priority; unresolved tasks are reported explicitly. Does not save changes.', inputSchema: draftInput, annotations: readonly},
  {name: 'draft_handoffs', title: 'Draft handoffs', description: 'Calculate a draft and prepare requests for changed owners with exact proposed times. Never sends messages, commits assignments, or marks tasks complete.', inputSchema: draftInput, annotations: readonly},
];
export function dispatch(message: unknown): unknown | null {
  if (!message || typeof message !== 'object' || Array.isArray(message)) return {jsonrpc: '2.0', id: null, error: {code: -32600, message: 'Invalid request'}};
  const request = message as {jsonrpc?: string; id?: unknown; method?: string; params?: Record<string, unknown>};
  const validId = request.id === undefined || typeof request.id === 'string' || (typeof request.id === 'number' && Number.isFinite(request.id));
  if (request.jsonrpc !== '2.0' || typeof request.method !== 'string' || !validId)
    return {jsonrpc: '2.0', id: validId ? request.id ?? null : null, error: {code: -32600, message: 'Invalid request'}};
  if (request.id === undefined) return null;
  const result = (value: unknown) => ({jsonrpc: '2.0', id: request.id, result: value});
  const error = (code: number, text: string) => ({jsonrpc: '2.0', id: request.id, error: {code, message: text}});
  if (request.method === 'initialize') return result({protocolVersion: PROTOCOL, capabilities: {tools: {listChanged: false}}, serverInfo: {name: 'HomeRelay', version: '1.1.0'}, instructions: 'Read sample data, calculate a draft, and inspect unresolved work before proposing handoffs. Tools are read-only. People explicitly approve and acknowledge changes in the web app. The web interface is an Alexa+ simulation; no live Alexa/device connection is claimed.'});
  if (request.method === 'ping') return result({});
  if (request.method === 'tools/list') return result({tools});
  if (request.method !== 'tools/call') return error(-32601, 'Method not found');
  const args = (request.params?.arguments || {}) as Record<string, unknown>, name = request.params?.name;
  try {
    let data: unknown;
    if (name === 'get_demo_household') {
      if (!args || typeof args !== 'object' || Array.isArray(args) || Object.keys(args).length) throw new Error('get_demo_household accepts no arguments.');
      data = initialState();
    } else if (name === 'replan_household') data = planHousehold(args.household, args.disruption);
    else if (name === 'draft_handoffs') data = {handoffs: handoffDraft(stateSchema.parse(args.household), planHousehold(args.household, disruptionSchema.parse(args.disruption)))};
    else return error(-32602, 'Unknown tool');
    return result({content: [{type: 'text', text: JSON.stringify(data)}], structuredContent: data, isError: false});
  } catch (failure) {return result({content: [{type: 'text', text: failure instanceof Error ? failure.message : 'Invalid arguments'}], isError: true});}
}
